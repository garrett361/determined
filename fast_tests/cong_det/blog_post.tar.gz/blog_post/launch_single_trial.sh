#!/usr/bin/env bash
det e create llama_13B_blog_post.yaml .
